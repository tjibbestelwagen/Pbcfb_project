The compressed file NPPSDv2.zip contains 7 files. 
Readme.txt � This file.
Users Guide to the North Pacific Seabird Database 2.0 � U.S. Geological Survey Open File Report describing this database and its use.
NPPSD_Front_v2.mdb � Graphical query form interface for filtering, crosstabulating and exporting data from the NPPSD 2.0 (Microsoft Access 2003 format).
NPPSD_Back_v2.mdb � Relational database of seabird and marine mammal observations on surveys in the North Pacific between 1973-2012. Data (Microsoft Access 2003 format).
NPPSD_Meta_2.0.xml � Metadata for the NPPSD 2.0 (xml format).
NPPSD_Meta_2.0.html � Metadata for the NPPSD 2.0 (html format).
NPPSD_Logo.png - NPPSD logo for use on maps or web sites.

Note Appendix E of the "Users Guide" provides instructions on the use of the graphical query form (NPPSD_Front_v2.mdb).